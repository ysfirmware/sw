jnhuamao technology co,. ltd.

www.jnhuamao.cn

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------

CC2540 Bluetooth Low Energy USB Dongle Firmware
Release Notes

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
Version 530
2016-05-17
Notices:

- Add some AT commands.
- Change some workflow of discovery.
- Add study function
  
Changes and Enhancements:

1. Add AT+COMI command, config Minimum Link Layer connection interval
   para1 value: 0 ~ 9; Default: 3(20ms);
   0: 7.5ms; 1: 10ms; 2: 15ms; 3: 20ms; 4: 25ms; 5: 30ms; 6: 35ms; 7: 40ms; 8: 45ms; 9: 4000ms
2. Add AT+COMA command, config Maximum Link Layer connection interval
   para1 value: 0 ~ 9; Default: 7(40ms);
   0: 7.5ms; 1: 10ms; 2: 15ms; 3: 20ms; 4: 25ms; 5: 30ms; 6: 35ms; 7: 40ms; 8: 45ms; 9: 4000ms
3. Add AT+COLA command, config Link Layer connection slave latency
   para1 value: 0 ~ 4; Default: 0;
4. Add AT+COSU command, config Link Layer connection supervision timeout
   para1 value: 0 ~ 6; Default: 6(6000ms);
   0: 100ms; 1: 1000ms; 2: 2000ms; 3: 3000ms; 4: 4000ms; 5: 5000ms; 6: 6000ms;
5. Add AT+COUP command, switch slave role update connection parameter
   para1 value 0, 1; Default: 1(Update on);
   0: Update off; 1: Update on;
6. Add AT+COMP command, switch study function
   para1 value 0, 1; Default: 0(Close study function);
   0: Close study function; 1: Open study function;

Version 526
2015-04-28

Notices:

- Add some AT commands.
- Change some workflow of discovery.
  
Changes and Enhancements:

1. Add AT+GAIN command, setup RX gain
   para1 value: 0~1


Version V523
2014-09-01

Changes and Enhancements:

- Remove AT+FILT command.
- Add AT+ADVI command.
- Fixed change uuid bugs.



Version V522
2014-02-03

Changes and Enhancements:

- Add Enable notify function.
- Fixed change uuid bugs.


Version V520
2014-01-03

Changes and Enhancements:

- Add AT+IBE0 command (Query/Set iBeacon UUID).
- Add AT+IBE1 command (Query/Set iBeacon UUID).
- Add AT+IBE2 command (Query/Set iBeacon UUID).
- Add AT+IBE3 command (Query/Set iBeacon UUID).
- Remove AT+IB1 command (Query/Set iBeacon UUID).
- Remove AT+IB2 command (Query/Set iBeacon UUID).


Version V519
2013-12-20

Changes and Enhancements:

- Add AT+ADTY command (Query/Set Advertising type)
- Add AT+MEAS command (Query/Set Measrued power)
- Add AT+IB1 command (Query/Set iBeacon UUID 01)
- Add AT+IB2 command (Query/Set iBeacon UUID 02)


Version V515
2013-12-18

Changes and Enhancements:

- Add AT+SHOW command (open/close if send name information when discovery)

Version V513
2013-12-13

Notices:

- Fix some bugs.
- Add some AT commands.
- Change some workflow of discovery.
  
Changes and Enhancements:

- Add AT+IBEA command (Open close iBeacon)
- Add AT+MARJ command (Query/Set iBeacon marjor)
- Add AT+MINO command (Query/Set iBeacon minor)
- Add AT+MODE command (Query/Set Dongle work mode)
  ?: Query mode
  0: Trans mode
  1: Remote config + Trans mode

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------

